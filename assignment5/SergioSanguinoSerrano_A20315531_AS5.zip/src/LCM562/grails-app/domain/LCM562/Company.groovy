package LCM562

class Company {

    String name
    
    static constraints = {
    }
    
    String toString() {
        "$name"
    } 
}
