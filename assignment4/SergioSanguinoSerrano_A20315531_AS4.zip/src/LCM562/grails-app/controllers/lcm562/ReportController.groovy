package lcm562

class ReportController {

    def scaffold = true
}
