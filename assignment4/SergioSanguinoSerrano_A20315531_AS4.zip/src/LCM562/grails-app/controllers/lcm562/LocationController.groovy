package lcm562

class LocationController {

    def scaffold = true
}
