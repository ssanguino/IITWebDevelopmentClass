package lcm562

class CompanyController {

    def scaffold = true
}
