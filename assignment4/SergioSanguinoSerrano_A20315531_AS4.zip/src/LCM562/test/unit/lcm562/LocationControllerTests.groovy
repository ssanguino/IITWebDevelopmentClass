package lcm562



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.web.ControllerUnitTestMixin} for usage instructions
 */
@TestFor(LocationController)
class LocationControllerTests {

    void testSomething() {
       fail "Implement me"
    }
}
